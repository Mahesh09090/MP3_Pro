#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "types.h"
typedef struct song
{
    char *song_name;
    FILE *fptr_song;

    char *duplicate_f_name;
    FILE *fptr_dup;
    char tag_name[5];
    char new_string[100];
    unsigned int size_of_string;

}mp3;

OperationType check_operation_type(char *argv);
Status open_file(mp3 *song);
Status check_header(mp3 *song);
Status viewing(mp3 *song);
Status copy_header(mp3 *song);
int read_size(FILE *fptr_song);
Status editing(mp3 *song);
Status open_files(mp3 *song);
int read_write(FILE *fptr_song,FILE *fptr_dup);
int Big_end(FILE *fptr_song);

