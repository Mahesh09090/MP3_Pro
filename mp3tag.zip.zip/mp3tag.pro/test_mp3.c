#include "mp3.h"

int main(char argc,char *argv[])
{
    int flg=1;
    char *tags[6]={"TPE1","TIT2","TALB","TYER","TCON","TCOM"};
    char *tags_names[6]={"Artist Name","Title Song","Album","Year","Contract type","Composer"};
    char *modifiers[6]={"-A","-T","-AB","-Y","-CT","-C"};
    
    if(argv[1]==NULL)
    {
        printf("ERROR : ./a.out : INVALID ARGUMENTS \n");
        printf("USAGE :\n");
        printf("To view pass like a : ./a.out -v <mp3.filename> \n");
        printf("To edit please pass like a : ./a.out -e -A/-T/-AB/-Y/-CT/-C changing text mp3 file\n");
        printf("To get help pass like  ./a.out --help\n");
        return 1;
    }   
    if((strcmp(argv[1],"--help")==0))
    {
        printf("For viewing tags :- ./a.out -v <mp3.file> \n");
        printf("  Tags         Tags_Names\n"); 
        printf("----------------------\n");
        for(int i=0;i<6;i++)
        {
            printf("  %-10s : %-30s\n",tags[i],tags_names[i]);
        }
        printf("\n");
        printf("For editing tags :- ./a.out -e <mp3.file> <modifier> <tag> \n\n");
        printf("  Tags         Modifiers\n"); 
        printf("----------------------\n");
        for(int i=0;i<6;i++)
        {
            printf("  %-10s : %-30s\n",tags[i],modifiers[i]);
        }
        return 1;
    }
    if(argv[2]==NULL)
    {
        printf("ERROR : ./a.out : INVALID ARGUMENTS \n");
        printf("USAGE :\n");
        printf("To view pass like a : ./a.out -v <mp3.filename> \n");
        printf("To edit please pass like a : ./a.out -e -A/-T/-AB/-Y/-CT/-C changing text mp3 file\n");
        printf("To get help pass like  ./a.out --help\n");
        return 1;
    }
    if(argv[2]!=NULL)
    {
        char *ptr=strstr(argv[2],".mp3");
        if(ptr==NULL)
        {
            printf("----------\n");
            printf("ERROR : ./a.out : INVALID ARGUMENTS \n");
            printf("USAGE :\n");
            printf("To view pass like a : ./a.out -v <mp3.filename> \n");
            printf("To edit please pass like a : ./a.out -e -A/-T/-AB/-Y/-CT/-C changing text mp3 file\n");
            printf("To get help pass like  ./a.out --help\n");
            return 1;
        }
    }
    int val=check_operation_type(argv[1]);   
    if(val==v_view)
    {
        printf("----------------------------------------------------------------\n");
        printf("            VIEW SONG INFORMATION             \n");
        printf("----------------------------------------------------------------\n");
        mp3 song;
        song.song_name=argv[2];
        viewing(&song);
        printf("----------------------------------------------------------------\n");
    }  
    if(val==e_edit)
    {
        
        printf("----------------------------------------------------------------\n");
        printf("           MOdify Mp3 2.3 Version File\n          \n");
        printf("----------------------------------------------------------------\n");
        mp3 song;
        song.duplicate_f_name=argv[4];
        int i=0,flag=0;
        int count=0;
        while(i<6)
        {
            if(strcmp(argv[2],modifiers[i])==0)
            {
                flag=1;
                break;
            }
            i++;
        }
        if(flag)
        {
            strcpy(song.tag_name,tags[i]);
        }
        else
        {
            printf("Enterd Modifiers is did'nt Matched To Tags\n");
            return failure;
        }
        strcpy(song.new_string,argv[3]);
        song.size_of_string=strlen(argv[3]);
        editing(&song);
    }
    return 0;
    
}
OperationType check_operation_type(char *argv)
{
   
    if(!(strcmp(argv,"-v")))
    {
        return v_view;
    }

    else if(!(strcmp(argv,"-e")))
    {
        return e_edit;
    }
    else
    {
        return unsupported;
    }
}

