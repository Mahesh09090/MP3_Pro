#include "mp3.h"
#include "types.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
Status check_header(mp3 *song)
{
    char buff[4];
    fread(buff,3,1,song->fptr_song);
    buff[4]='\0';
    int res=strcmp(buff,"ID3");
    if(res==0)
    {
        return success;
    }
    return failure;
}
Status open_file(mp3 *song)
{
    if(strstr(song->song_name,".mp3"))
    {
        song->fptr_song= fopen(song->song_name,"r");
        if (song->fptr_song == NULL)
        {
            perror("fopen");
            fprintf(stderr, "ERROR: Unable to open file %s\n", song->song_name);
            return failure;
        }
        return success;
    }
    else
    {
        printf("Enter valid file name");
        return failure;
    }
    return success;
}
int read_size(FILE *fptr_song)
{
    int num;
    fread(&num,4,1,fptr_song);
    int i=0;
    while(i<2)
    {
        char temp=*((char*)(&num)+i);
        *(((char*)(&num)+i))=*(((char*)(&num)+(4-i-1)));
        *(((char*)(&num)+(4-i-1)))=temp;
        i++;
    }
    return num;
}
Status viewing(mp3 *song)
{
    char *tags[6]={"TPE1","TIT2","TALB","TYER","TCON","COMM"};
    char *tags_names[6]={"Artist Name","Title Song","Album","Year","Contract type","Comments"};
    if(open_file(song)==success)
    {
        if(check_header(song)==success)
        {
            fseek(song->fptr_song,10,SEEK_SET);
            for(int i=0;i<6;i++)
            {
                char buff[4];

                fread(buff,4,1,song->fptr_song);

                buff[4]='\0';

                int i=0,flag=0;

                while(i<6)
                {
                    if((strcmp(buff,tags[i])==0))
                    {
                        flag=1;
                        break;

                    }
                    i++;
                }
                if(flag)
                {
                    int size=read_size(song->fptr_song);

                    fseek(song->fptr_song,3,SEEK_CUR);
                    
                    char s[size];

                    fread(s,size-1,1,song->fptr_song);

                    s[size-1]='\0';

                    printf("%-15s  : %-30s\n", tags_names[i], s);

                }
                else
                {
                    break;
                    return failure;
                }
                
            }
            fseek(song->fptr_song,0,SEEK_SET);
        }
        else
        {
            printf("Version Not Matched\n");
            return failure;
        }
    }
    else
    {
        printf("Unable to open file\n");
        return failure;
    }
    
}
Status open_files(mp3 *song)
{
    song->fptr_song = fopen("sample.mp3", "r");
    if (song->fptr_song == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", song->song_name);
        return failure;
    }
    if(strstr(song->duplicate_f_name,".mp3"))
    {
        song->fptr_dup= fopen(song->duplicate_f_name, "w");
        if (song->fptr_dup == NULL)
        {
            perror("fopen");
            fprintf(stderr, "ERROR: Unable to open file %s\n", song->duplicate_f_name);
            return failure;
        }
        return success;
    }
    else
    {
        printf("Enter valid file name");
        return failure;
    }
    return success; 
}
Status copy_header(mp3 *song)
{
    char buff[10];
    fread(buff,10,1,song->fptr_song);
    fwrite(buff,10,1,song->fptr_dup);
    return success;
}
int read_write(FILE *fptr_song,FILE *fptr_dup)
{
    int num;
    fread(&num,4,1,fptr_song);
    fwrite(&num,4,1,fptr_dup);
    int i=0;
    while(i<2)
    {
        char temp=*((char*)(&num)+i);
        *(((char*)(&num)+i))=*(((char*)(&num)+(4-i-1)));
        *(((char*)(&num)+(4-i-1)))=temp;
        i++;
    }
    return num;
}
Status editing(mp3 *song)
{
    if(open_files(song)==success)
    {
        if(copy_header(song)==success)
        {
            for(int i=0;i<6;i++)
            {
                char buff[4];
                fread(buff,4,1,song->fptr_song);
                buff[4]='\0';
                if(strcmp(buff,song->tag_name)==0)
                {
                    fwrite(buff,4,1,song->fptr_dup);
                    int size=read_size(song->fptr_song);
                    int num=(song->size_of_string);
                    int i=0;
                    while(i<2)
                    {
                        char temp=*((char*)(&num)+i);
                        *(((char*)(&num)+i))=*(((char*)(&num)+(4-i-1)));
                        *(((char*)(&num)+(4-i-1)))=temp;
                        i++;
                    }
                    fwrite(&(num),4,1,song->fptr_dup);
                    char fug[3];
                    fread(fug,3,1,song->fptr_song);
                    fwrite(fug,3,1,song->fptr_dup);
                    fseek(song->fptr_song,size-1,SEEK_CUR);
                    fwrite(song->new_string,song->size_of_string-1,1,song->fptr_dup);
                    char ch;
                    while(fread(&ch, 1, 1,song-> fptr_song) != EOF)
                    {
                        fwrite(&ch, 1, 1, song->fptr_dup);
                    }
                    fclose(song->fptr_dup);
                    break;
                }
                else
                {
                    fwrite(buff,4,1,song->fptr_dup);
                    int size=read_write(song->fptr_song,song->fptr_dup);
                    char flag[3];
                    fread(flag,3,1,song->fptr_song);
                    fwrite(flag,3,1,song->fptr_dup);
                    char s[size];
                    fread(s,size-1,1,song->fptr_song);
                    fwrite(s,size-1,1,song->fptr_dup);
                }
            }
            printf("%ld\n",ftell(song->fptr_song));
            printf("%ld\n",ftell(song->fptr_dup));
        }
    }
    return failure;
}
